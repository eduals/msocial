---
layout: post
title: Ngôn ngữ lập trình nào tốt nhất?
categories: [language]
tags: [code, developer]
description: Java, C/C++, C#, Python, ASP.Net, Ruby, NodeJS, PHP,...
---

Xin chào các bạn, nếu các bạn đến với bài viết vì vì cái câu hỏi vu vơ kia và cũng chỉ để xem ngôn ngữ lập trình nào là tốt nhất, để rồi đắc ý khoe khoang thứ ngôn ngữ mình đang theo là đỉnh cao nhất, là anh cả của các ông dung ngôn ngữ khác, thì thực sự xin lỗi bạn sẽ không tìm được thứ như mình mong muốn đâu.
Vậy, ngôn ngữ lập trình nào tốt nhất, mình xin mạo muội nói rằng các bạn không thể đem so sánh ngôn ngữ nào hơn ngôn ngữ nào, vì đơn giản mỗi ngôn ngữ lập trình đều có điểm mạnh điểm yếu riêng, cũng như nó thích hợp với từng nền tảng khác nhau, chả ai đem Passcal đi để lập trình web cả, cũng chả ai đem PHP để viết mấy cái chương trình console tính toán cơ bản đâu.


Vậy tại sao vẫn phân các ngôn ngữ lập trình làm chi, sao không làm 1 cho tất cả: thực ra thì mình nghĩ điều này ai chả muốn, nhưng mọi người hãy xem rằng khi lập trình mới nhen nhóm phát triển thì có hàng trăm nghìn tổ chức cùng phát triển, nó sẽ rẽ nhiều nhánh khác nhau, và tất nhiên nó sẽ không thể hợp nhất được. điều các bạn cần là hãy làm đi, và cần những gì để đủ làm với nó, đó chính là kiến thức về hướng đối tượng, kĩ năng thao tác với hệ cơ sở dữ liệu và các thuật toán tối ưu siêu dị của chính bạn là chìa khóa để trở thành những người Dev tốt nhất...
Và điều quan trọng để bạn tiếp cận các ngôn ngữ đó là hiểu nó là gì, thông dịch, biên dịch hay có hướng đối tượng hay không? Để có thể lựa chọn phù hợp nhất cho sản phẩm sắp phát triển của bạn. Vậy tiếp theo mình sẽ nói sơ qua về các khái niệm phân biệt ngôn ngữ lập trình kia cho những bạn nào đang quan tâm:


Thông dịch hay biên dịch:

- Thông dịch là gì? Thông dịch hay còn có thể gọi là ngôn ngữ hướng dòng, Nghĩa là khi chương trình của bạn chạy, thì sẽ chẳng cần qua khâu biên dịch mà chạy được ngay, đến dòng nào nó làm công việc đó, và đến dòng lỗi chương trình sẽ đứng lại không đi tiếp (Chúng ta ko đề cập tới sử dụng khái niệm ‘ngoại lệ’ ở đây nhé), thông dịch phổ biến ở các ngôn ngữ lập trình web như PHP, Python hay ở Ngôn ngữ máy huyền thoại Assembly mà ko phải ai cũng dám sờ vào nó/ Với những loại này thì hiệu quả chương trình với hiệu năng thời gian nhanh hơn hẳn, vì chẳng mất thời gian để build chương trình cũng như code đến đâu test luôn đến đó. Cơ chế bảo mật ko thể cao hơn biên dịch, dễ dàng bỏ sót các lỗi Sytax Error trong lập trình.

- Biên dịch là gì? Biên dịch lại đi ngược với thông dịch, trước khi chương trình được chạy thì nó cần được biên dịch thành 1 tệp tin chương trình trước, và quá trình này sẽ rà soát các lỗi Sytax Error để ko cho phép chương trình được biên dịch nếu còn lỗi cú pháp. Và tất nhiên thời gian cho các chương trình này sẽ cần thời gian biên dịch chương trình trước, cũng như cần khai báo 1 hàm main để chương trình chạy nó trước (Không giống với thông dịch, chạy file nào thì thực hiện lệnh ở đó, không cần khai báo hàm main). Và tất nhiên biên dịch sẽ không thể gặp lỗi cú pháp khi chương trình chạy cũng như bảo mật tốt hơn. Những ngôn ngữ biên dịch phổ biến như: C++, C#, Java.


Vậy còn hướng đối tượng hay hướng cấu trúc: 

- Hầu hết các ngôn ngữ hiện nay đều là hướng đối tượng trừ C thì vẫn hướng cấu trúc, và hiểu nôm na hướng đối tượng giống như một kiểu mở rộng của hướng cấu trúc.

- Hướng cấu trúc là các khối lệnh được sử dụng nhiều lần sẽ được nhóm lại thành một hàm xử lý riêng biệt và được dùng lại mỗi khi cần, cũng như các câu lệnh sẽ được thực thi theo trình tự hay lặp đi lặp lại nhiều lần.

- Còn hướng đối tượng thì được mở rộng hơn với các Lớp, đối tượng và Khái niệm đóng gói, Hay có thể là Blocking hay Non-Blocking, Và đây chính là giải pháp để chúng ta có thể phát triển các ứng dụng với sự phân cấp các chức năng sâu hơn, rõ ràng hơn hay thể hiện gần sát nhất với chức năng của từng đối tượng cũng như thể hiện sự liên quan của các đối tượng tới nhau như kế thừa, kết tập và có thể tạo nhiều đối tượng có các hành động gần giống nhau mà lại mang các thuộc tính khác nhau…


Trên đây là ý kiến chủ quan của mình về những khái niệm căn bản trong lập trình, mong rằng giúp ích cho các bạn, hẹn gặp lại các bạn trong bài viết tiếp theo.

K.T Buminta.
