---
layout: post
title: Tâm lý ngại chia sẻ
categories: [blog]
tags: [blog]
description: Chúng ta cùng nhìn vào tổng quan của (CNTT) từ những ngày đầu sẽ thấy rằng sự chia sẻ trong nó là không ngừng nghỉ…
---

Ngành CNTT hay vốn bản chất được đi lên từ ngành Khoa học máy tính với những nhu cầu tính toán số học của con người, từ những chiếc máy tính điện tử đầu tiên như ENIAC (ra đời năm 1946) là một thiết bị khổng lồ nặng hàng tấn, mãi đến 1970 người ta bắt đầu nghiên cứu ra mạng viễn thông để kết nối và liên lạc các máy tính lại với nhau, cùng với sự phát triển không ngừng nghỉ Internet được ấp ủ từ đó cho đến những năm 1994 có được kết nối TCP/IP và 1991 chúng ta có WWW (Một ý tưởng về siêu văn bản để có được những website ngày hôm nay). Sau đó là 1994 TCP/IP được quy chuẩn, chúng ta có những Video chia sẻ đầu tiên trên mạng Internet. Cùng với sự phát triển đó thì Việt Nam cũng hoà vào mạng Internet toàn cầu năm 1997 sau những cố gắng từ năm 1994.
Nhìn chung là vậy nhưng để Internet bây giờ phát triển tại Việt Nam hay toàn thế giới chóng mặt như vậy chúng ta không thể không kể đến những sự chia sẻ của cộng đồng từ những ngày đầu tiên cho đến tận bây giờ đã có rất nhiều những công nghệ mới mà chúng ta phải luôn luôn tìm tòi và học hỏi nó.
Học ở đâu? thì câu trả lời rõ ràng đó là từ Internet.
Vì sao CNTT lại được Ấn Độ chú trọng đưa vào một trong những ngành công nghiệp trọng điểm thì câu trả lời là ở sự lớn mạnh của CNTT bây giờ. Cũng như chúng ta có thể thoải mái tham gia vào những cộng đồng CNTT lớn mạnh trên toàn thế giới để học hỏi và chia sẻ mà không hề tốn kém chi phí đi lại hay học phí cả.

Tôi bước vào Công nghệ thông tin (CNTT) từ khi còn rất nhỏ, và mọi thứ luôn bắt đầu từ con số 0 tròn trĩnh. Để có được những bước tiến như ngày hôm nay thì việc không ngừng cố gắng học hỏi và chia sẻ là không thể thiếu. Và ở đâu chúng ta có được những sự chia sẻ quý báu đó, đó chính ở tâm lý “không ngại” chia sẻ của mỗi cá nhân mong muốn học hỏi.

Tôi cũng đã gặp gỡ nhiều người, tiếp xúc và sẻ chia với họ. Và tôi vẫn luôn thắc mắc có những người không hề ngại khó, luôn luôn học hỏi và sẵn sàng chia sẻ với người khác, đó là số ít. Còn lại tâm lý chung những người có bề dày kiến thức lại ít chia sẻ kinh nghiệm của bản thân, hay nói cách khác họ thường lắng nghe nhiều hơn để biết thêm được nhiều cho bản thân chứ chưa chắc giúp bản thân đối phương có được nhiều kiến thức hơn.
Cũng có những người thì hiểu biết quá ít nên không hề chia sẻ giống như một dạng tâm lý ngại chia sẻ kiểu “giấu dốt”, vì chính họ sợ rằng khi nói ra sẽ bị người khác so sánh và không tôn trọng. hay ở chính bản thân những người mong muốn được chia sẻ lại không thể tìm đến nhau.

Đó cũng là câu chuyện trải nghiệm khi tôi trải qua khá nhiều công ty về CNTT ở Việt Nam hiện nay. Tôi đều may mắn được gặp các bạn thực tập viên, sinh viên đang học và chia sẻ kinh nghiệm chuyên ngành của mình với các bạn, và không quên nhắn nhủ rất nhiều rằng tôi luôn luôn sẵn sàng chia sẻ hay hỗ trợ các bạn tìm hiểu bất cứ khi nào các bạn gặp khó, cũng như luôn luôn tiếp thu các kiến thức mới khi các bạn biết mà tôi cũng chập chững tìm hiểu để cùng nhau tiến bộ. Và tất nhiên sau những lần đó thì kết quả rằng con số tìm đến tôi chỉ có thể đếm trên đầu ngón tay (cũng tốt vì dù sao mỗi đầu ngón tay đó đều có sự tiến triển rõ ràng). 
Vậy tôi đi tìm nguyên nhân cho chính những kết quả đó thì có chia rằng tâm lý “ngại chia sẻ" được chia làm 3 loại chính:
Ngại làm phiền (vì chính bản thân các bạn không hề muốn bị làm phiền),
Giấu dốt hay giấu kiến thức (nguyên do rằng các bạn luôn tự ti về bản thân mà sợ chia sẻ với người khác sẽ làm mình kém đi hoặc cũng như bị người khác vượt qua), 
Thiếu lòng tin hay kiêu ngạo (bản thân bạn tự cảm thấy mình giỏi và người khác không thể làm được, cũng như cảm thấy rằng không tin tưởng đối phương sẽ cùng giúp cho cả 2 tiến bộ lên)

Tuy nhiên nhìn về khía cạnh con người chúng ta trong những giai đoạn thăng trầm phát triển của đất nước, chiến tranh, áp bức bóc lột rồi đến sự phân hoá giàu nghèo làm cho con người ta bớt gần lại với nhau, ít chia sẻ với nhau đi. để mãi không thể thoát ra khỏi cái tâm lý “ngại chia sẻ”.