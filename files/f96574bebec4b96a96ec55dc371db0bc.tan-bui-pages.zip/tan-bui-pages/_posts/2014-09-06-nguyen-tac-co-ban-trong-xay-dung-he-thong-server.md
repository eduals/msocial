---
layout: post
title: Nguyên tắc quan trọng trong xây dựng hệ thống (server)
categories: [developer]
tags: [server]
description: Ghi log chi tiết tất cả mọi thứ, mọi lúc...
---

- Ghi log chi tiết tất cả mọi thứ, mọi lúc. Dữ liệu log trong database tránh tham chiếu đến các bảng db khác mà lưu giá trị cụ thể, ví dụ: log product thì ngoài product id phải lưu cả product_price, product_title... để tránh các giá trị thay đổi theo thời gian bởi người dùng
- Xây dựng hệ thống error trace chi tiết và rõ ràng phục vụ cho debug và dễ dàng xóa bỏ khi deploy
- Quản lý danh sách các tài khoản test, sandbox để dễ dàng và chính xác trong việc thống kê và remove khi deploy chính thức
- Cung cấp hệ thống bảo mật, xác thực ngay từ đầu 1 cách tổng quát cho chức năng, tài khoản truy cập, token cho bên thứ 3 để quản lý việc ai được sử dụng chức năng..., ghi log truy cập của người dùng... Ví dụ cp muốn sử dụng api thì phải đăng ký api_key dành riêng cho mỗi cp, giúp cho việc log và quản lý dễ dàng, bảo mật...
- Luôn luôn backup dữ liệu:
     + source qua svn bằng cách tạo quy trình deployment với branchs, tags... 
          Ví dụ: khi deploy product thì cần:
          . tạo 1 bản tag theo version kèm ngày tương ứng 1.0.20140109, 2.3.20140103... 
          . sau đó export ra thư mục deployment
          khi cần sửa 1 chức năng nhỏ trong bản release 1.0.20130518 mà source đang phát triển cho 2.0 rồi thì cần:
          . tạo 1 bản branch từ bản tag 1.0.20130518 với tên là "version_mục_đích_thay_đổi"
          . sau đó sửa trên bản branch đến khi hoàn thiện
          . cập nhật sang source trunk
          . tạo tag với version cũ và ngày release vd: 1.0.20130624
          . backup thư mục source deployment vào 1 thư mục backup với tên thư mục là ngày tháng năm backup như 20140901
          . export đè vào thư mục source deployment
     + databases backup tự động định kỳ hàng ngày/tuần/tháng
     + backup databases manual mỗi lần nâng cấp hệ thống, test hệ thống
- Luôn sao database chính ra 1 db tạm khi thử chức năng mới mà có kết nối đến db kể cả có chỉnh sửa db hay ko
- Tạo thư mục source, database, tk riêng cho mỗi developer trong quá trình dev, ko dùng chung với db và deployed source
- Lưu tất cả tài khoản liên quan đến hệ thống như tk server, database, svn, quản trị... xuống note, server hoặc lưu trữ vào bất kỳ nơi nào an toàn, đảm bảo và cập nhật ngay khi có sự thay đổi
- Nghiêm chỉnh chấp hành các quy trình bảo mật và an toàn dữ liệu trên dù chỉ thay đổi nhỏ hoặc đơn giản