---
layout: post
title: Chat Realtime WNodeJS
categories: [nodejs]
tags: [nodejs, mvc, realtime, wnodejs]
description: Framework WNodeJS - https://github.com/Buminta/WNodeJS.
---

[Beta version from git](https://github.com/Buminta/Node)


Node listening with port 3000

 - Chat Real time with NodeJS, Socket.IO, ExpressJS, Jade Template
 - Create room chat and join to any room
 - Using demo MVC lite, with Express JS


Listening MongoDB
{% highlight javascript %}
var server = new Server('127.0.0.1', 27017, {auto_reconnect: true});
var db = new Db('chatnode', server, {safe:false});
{% endhighlight %}

Restore database MongoDB for demo
{% highlight javascript %}
  from "./database/chatnode"
  user/password: admin/123456
{% endhighlight %}